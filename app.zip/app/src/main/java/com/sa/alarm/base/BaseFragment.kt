package com.sa.alarm.base

import androidx.fragment.app.Fragment

abstract class BaseFragment : Fragment() {

}